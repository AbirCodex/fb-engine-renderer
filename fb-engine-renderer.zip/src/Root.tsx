import React, { useEffect, useState } from "react";
import { Composition, continueRender, delayRender } from "remotion";
import { CardProps, STILL_FRAMES, TEMPLATES } from "./stills/templates";
import { REELS, ReelProps, reelDuration } from "./videos/reels";

// Block rendering until web fonts are ready, so text is measured in the real font.
const useFonts = () => {
  const [h] = useState(() => delayRender("fonts"));
  useEffect(() => { document.fonts.ready.then(() => continueRender(h)); }, [h]);
};

const Card: React.FC<CardProps> = (p) => {
  useFonts();
  const T = TEMPLATES[p.template] ?? TEMPLATES.T01;
  return <T {...p} />;
};

const Reel: React.FC<ReelProps> = (p) => {
  useFonts();
  const V = REELS[p.format] ?? REELS.V1;
  return <V {...p} />;
};

// Minimal defaults: input props replace these, so nothing from a sample leaks into a real card.
const sampleCard: CardProps = { page: "EN", template: "T01", headline: "Sample [headline]" };

export const Root: React.FC = () => (
  <>
    <Composition id="Card" component={Card} width={1080} height={1350} fps={30} durationInFrames={STILL_FRAMES} defaultProps={sampleCard} />
    <Composition id="Reel" component={Reel} width={1080} height={1920} fps={30} durationInFrames={600}
      defaultProps={{ page: "EN", format: "V1", scenes: [] } as ReelProps}
      calculateMetadata={({ props }) => ({ durationInFrames: reelDuration(props as ReelProps) })} />
  </>
);
