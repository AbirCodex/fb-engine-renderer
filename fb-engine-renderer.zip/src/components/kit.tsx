import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig, Img, staticFile } from "remotion";
import { Brand, Page, localNum } from "../theme";

// ---------- layers: background mesh -> content -> grade -> grain -> vignette ----------
export const BgMesh: React.FC<{ b: Brand; still?: boolean }> = ({ b, still }) => {
  const f = still ? 0 : useCurrentFrame();
  const d1 = Math.sin(f / 55) * 50;
  const d2 = Math.cos(f / 70) * 40;
  return (
    <AbsoluteFill style={{ background: b.colors.bg }}>
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -420 + d1, filter: "blur(60px)", background: `radial-gradient(circle, ${b.colors.hero}22, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1100, height: 1100, borderRadius: "50%", bottom: -520, right: -380 - d2, filter: "blur(80px)", background: `radial-gradient(circle, ${b.colors.surface}, transparent 66%)` }} />
      {/* fine grid gives an editorial "lab" texture instead of a flat fill */}
      <AbsoluteFill style={{ backgroundImage: `linear-gradient(${b.colors.line} 1px, transparent 1px), linear-gradient(90deg, ${b.colors.line} 1px, transparent 1px)`, backgroundSize: "72px 72px", opacity: 0.35, maskImage: "radial-gradient(ellipse at 50% 40%, black 30%, transparent 75%)" }} />
    </AbsoluteFill>
  );
};

export const Grade: React.FC<{ b: Brand }> = ({ b }) => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: b.colors.hero, mixBlendMode: "soft-light", opacity: 0.06 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 25%, transparent 75%, rgba(0,0,0,0.22))" }} />
  </AbsoluteFill>
);

export const Grain: React.FC<{ still?: boolean }> = ({ still }) => {
  const f = still ? 0 : useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px", backgroundPosition: `${(f * 7) % 220}px ${(f * 13) % 220}px`, opacity: 0.07, mixBlendMode: "overlay" }} />;
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 58%, rgba(0,0,0,0.28) 100%)" }} />
);

export const Frame: React.FC<{ b: Brand; still?: boolean; children: React.ReactNode }> = ({ b, still, children }) => (
  <AbsoluteFill style={{ fontFamily: b.fonts.body, color: b.colors.text }}>
    <BgMesh b={b} still={still} />
    <AbsoluteFill style={{ padding: b.safe, display: "flex", flexDirection: "column" }}>{children}</AbsoluteFill>
    <Grade b={b} />
    <Grain still={still} />
    <Vignette />
  </AbsoluteFill>
);

// ---------- motion primitives ----------
export const useP = (delay: number, cfg: "snappy" | "smooth" | "bouncy", b: Brand) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: b.spring[cfg] });
};

export const Entrance: React.FC<{ b: Brand; delay?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ b, delay = 0, children, style }) => {
  const p = useP(delay, "smooth", b);
  return (
    <div style={{ opacity: p, transform: `translateY(${interpolate(p, [0, 1], [40, 0])}px) scale(${interpolate(p, [0, 1], [0.95, 1])})`, ...style }}>{children}</div>
  );
};

// "Why [42% of Meta spend] leaks" -> accent words get a hero marker underline.
export const AccentText: React.FC<{ b: Brand; text: string; size: number; delay?: number; color?: string; heroWords?: boolean }> = ({ b, text, size, delay = 0, color, heroWords }) => {
  const parts = text.split(/(\[[^\]]+\])/g).filter(Boolean);
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  let wi = 0;
  return (
    <div style={{ fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: size, lineHeight: b.tracking === "0em" ? 1.32 : 1.08, letterSpacing: b.tracking, color: color ?? b.colors.text, display: "flex", flexWrap: "wrap", justifyContent: heroWords ? "center" : "flex-start", columnGap: Math.round(size * 0.26), rowGap: Math.round(size * 0.08) }}>
      {parts.flatMap((part, pi) => {
        const accent = part.startsWith("[");
        const words = (accent ? part.slice(1, -1) : part).split(/\s+/).filter(Boolean);
        // "[ফেরত যায়]?" -> the "?" sticks to the previous word instead of floating after a gap.
        const glue = pi > 0 && !accent && !/^\s/.test(part);
        return words.map((w, i) => {
          const p = spring({ frame: frame - delay - wi++ * 3, fps, config: b.spring.snappy });
          const bar = spring({ frame: frame - delay - wi * 3 - 5, fps, config: b.spring.smooth });
          return (
            <span key={`${pi}-${i}`} style={{ position: "relative", display: "inline-block", marginLeft: glue && i === 0 ? -Math.round(size * 0.26) : 0, opacity: p, transform: `translateY(${interpolate(p, [0, 1], [28, 0])}px)`, color: accent && heroWords ? b.colors.hero : undefined }}>
              {accent && !heroWords && (
                <span style={{ position: "absolute", left: -4, right: -4, bottom: size * 0.04, height: size * 0.26, background: b.colors.hero, opacity: 0.9, transformOrigin: "0 50%", transform: `scaleX(${bar})`, zIndex: -1, borderRadius: 4 }} />
              )}
              <span style={{ position: "relative", color: accent && !heroWords ? b.colors.text : undefined }}>{w}</span>
            </span>
          );
        });
      })}
    </div>
  );
};

export const Eyebrow: React.FC<{ b: Brand; text: string; delay?: number }> = ({ b, text, delay = 0 }) => {
  const p = useP(delay, "snappy", b);
  return (
    <div style={{ alignSelf: "flex-start", opacity: p, transform: `translateX(${interpolate(p, [0, 1], [-30, 0])}px)`, display: "flex", alignItems: "center", gap: 14, padding: "12px 22px", borderRadius: 999, border: `2px solid ${b.colors.line}`, background: "rgba(255,255,255,0.04)", fontSize: 26, fontWeight: 700, letterSpacing: b.tracking === "0em" ? "0.02em" : "0.12em", textTransform: "uppercase", color: b.colors.dim }}>
      <span style={{ width: 12, height: 12, borderRadius: 6, background: b.colors.hero }} />
      {text}
    </div>
  );
};

// Animated number; prefix/suffix stay static so the width does not jump.
export const Counter: React.FC<{ b: Brand; page: Page; value: number; decimals?: number; prefix?: string; suffix?: string; size: number; delay?: number; color?: string }> = ({ b, page, value, decimals = 0, prefix = "", suffix = "", size, delay = 0, color }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: { damping: 30, stiffness: 60 } });
  const v = interpolate(p, [0, 1], [0, value]);
  const shown = v.toLocaleString("en-US", { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
  return (
    <div style={{ fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: size, lineHeight: 1, letterSpacing: b.tracking, color: color ?? b.colors.hero, fontVariantNumeric: "tabular-nums", textShadow: `0 0 60px ${(color ?? b.colors.hero)}55`, opacity: Math.min(1, p * 3) }}>
      {localNum(page, prefix + shown + suffix)}
    </div>
  );
};

export const Footer: React.FC<{ b: Brand; page: Page; cue?: string; delay?: number }> = ({ b, cue, delay = 0 }) => {
  const p = useP(delay, "smooth", b);
  return (
    <div style={{ marginTop: "auto", opacity: p, transform: `translateY(${interpolate(p, [0, 1], [20, 0])}px)`, display: "flex", flexDirection: "column", gap: 18 }}>
      {cue && <div style={{ fontSize: 30, fontWeight: 700, color: b.colors.text }}>{cue}</div>}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderTop: `2px solid ${b.colors.line}`, paddingTop: 20, fontSize: 24, color: b.colors.dim }}>
        <span style={{ fontWeight: 700, color: b.colors.text }}>{b.handle}</span>
      </div>
    </div>
  );
};

export const OwnerCutout: React.FC<{ src: string; height: number; still?: boolean }> = ({ src, height, still }) => {
  const f = still ? 0 : useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const scale = still ? 1 : interpolate(f, [0, durationInFrames], [1, 1.06], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return <Img src={src.startsWith("http") ? src : staticFile(src)} style={{ height, objectFit: "contain", transform: `scale(${scale})`, transformOrigin: "50% 100%", filter: "drop-shadow(0 30px 50px rgba(0,0,0,0.45))" }} />;
};
