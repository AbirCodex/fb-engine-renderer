import React from "react";
import { AbsoluteFill, Audio, interpolate, OffthreadVideo, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { TransitionSeries, springTiming, TransitionPresentation } from "@remotion/transitions";
import { slide } from "@remotion/transitions/slide";
import { wipe } from "@remotion/transitions/wipe";
import { fade } from "@remotion/transitions/fade";
import { AccentText, Counter, Entrance, Frame, OwnerCutout, useP } from "../components/kit";
import { brandOf, localNum, Page, Brand } from "../theme";

// Storyboard written by A4 Art Director. 15-30 s, 1080x1920, 30 fps.
// Retention rules (reels-script skill): hook readable on mute at frame 0, a new visual every 2-4 s,
// value before the ask, and an end line that loops back to the hook.
export type Scene =
  | { type: "hook"; sec: number; style?: "stack" | "punch" | "strike"; text: string; wrong?: string }
  | { type: "stat"; sec: number; value: number; prefix?: string; suffix?: string; decimals?: number; label: string }
  | { type: "steps"; sec: number; title: string; items: string[] }
  | { type: "checklist"; sec: number; title: string; items: string[] }
  | { type: "compare"; sec: number; before: { label: string; text: string }; after: { label: string; text: string } }
  | { type: "versus"; sec: number; them: { label: string; points: string[] }; us: { label: string; points: string[] } }
  | { type: "bars"; sec: number; title: string; unit?: string; before: { label: string; value: number }; after: { label: string; value: number } }
  | { type: "type"; sec: number; title: string; prompt: string }
  | { type: "punch"; sec: number; words: string[] }
  | { type: "statement"; sec: number; text: string }
  | { type: "end"; sec: number; cue: string; owner_photo?: string };
export type ReelProps = { page: Page; format: string; scenes: (Scene & { bg?: string })[]; music?: boolean };

const FPS = 30;
const T = 10; // transition frames
const BEAT = 18; // music bed is 100 BPM -> 18 frames per beat; scene lengths snap to whole beats so cuts land on the beat
const len = (sec: number) => Math.max(BEAT * 2, Math.round((sec * FPS) / BEAT) * BEAT);
export const reelDuration = (p: ReelProps) =>
  Math.max(30, p.scenes.reduce((s, sc) => s + len(sc.sec), 0) - T * Math.max(0, p.scenes.length - 1));

// Optional real B-roll (Pexels) behind a scene, darkened so text stays readable.
const BRoll: React.FC<{ src: string }> = ({ src }) => (
  <AbsoluteFill>
    <OffthreadVideo src={src} muted style={{ width: "100%", height: "100%", objectFit: "cover", opacity: 0.38 }} />
    <AbsoluteFill style={{ background: "linear-gradient(180deg, rgba(0,0,0,0.55), rgba(0,0,0,0.25) 40%, rgba(0,0,0,0.6))" }} />
  </AbsoluteFill>
);

// Content sits in the middle ~75% of the 9:16 frame (platform UI covers top/bottom).
const Safe: React.FC<{ children: React.ReactNode; center?: boolean }> = ({ children, center }) => (
  <div style={{ position: "absolute", left: 80, right: 80, top: 260, bottom: 360, display: "flex", flexDirection: "column", justifyContent: center ? "center" : "flex-start", gap: 40 }}>{children}</div>
);

const Breathe: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const f = useCurrentFrame();
  return <div style={{ transform: `translateY(${Math.sin(f / 30) * 4}px) scale(${1 + Math.sin(f / 22) * 0.008})` }}>{children}</div>;
};

// Huge outlined scene number drifting behind the content: depth without competing with text.
const Ghost: React.FC<{ n: number; b: Brand }> = ({ n, b }) => {
  const f = useCurrentFrame();
  return <div style={{ position: "absolute", right: -40, top: 230 - f * 0.6, fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: 620, lineHeight: 1, color: "transparent", WebkitTextStroke: `3px ${b.colors.line}`, opacity: 0.9 }}>{String(n).padStart(2, "0")}</div>;
};

const Card: React.FC<{ b: Brand; tone?: string; children: React.ReactNode; style?: React.CSSProperties }> = ({ b, tone, children, style }) => (
  <div style={{ borderRadius: 30, padding: "34px 40px", border: `3px solid ${tone ? tone + "88" : b.colors.line}`, background: tone ? `${tone}14` : "rgba(255,255,255,0.05)", ...style }}>{children}</div>
);
const Label: React.FC<{ b: Brand; page: Page; tone: string; children: React.ReactNode }> = ({ b, page, tone, children }) => (
  <div style={{ fontSize: 32, fontWeight: 800, letterSpacing: page === "BN" ? "0.02em" : "0.1em", textTransform: "uppercase", color: tone }}>{children}</div>
);

// Hook: "punch" = one word at a time, huge, slamming in.
const PunchWords: React.FC<{ b: Brand; words: string[]; size: number; instant?: boolean }> = ({ b, words, size, instant }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {words.map((w, i) => {
        const p = spring({ frame: f - (instant ? -20 + i * 4 : i * 8), fps, config: b.spring.bouncy });
        const accent = /^\[.*\]$/.test(w);
        return (
          <div key={i} style={{ fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: size, lineHeight: 1.05, letterSpacing: b.tracking, color: accent ? b.colors.hero : b.colors.text, opacity: Math.min(1, p * 2), transform: `scale(${interpolate(p, [0, 1], [1.6, 1])}) translateY(${interpolate(p, [0, 1], [-30, 0])}px)`, transformOrigin: "0 50%" }}>
            {w.replace(/^\[|\]$/g, "")}
          </div>
        );
      })}
    </div>
  );
};

// Hook: "strike" = the common belief appears, gets crossed out, the real point lands.
const Strike: React.FC<{ b: Brand; page: Page; wrong: string; text: string; size: number }> = ({ b, wrong, text, size }) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  const line = spring({ frame: f - 14, fps, config: b.spring.snappy });
  return (
    <>
      <div style={{ position: "relative", alignSelf: "flex-start", fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: size * 0.7, lineHeight: 1.15, color: b.colors.dim }}>
        {wrong}
        <div style={{ position: "absolute", left: -8, right: -8, top: "52%", height: 10, borderRadius: 5, background: b.colors.alert, transformOrigin: "0 50%", transform: `scaleX(${line}) rotate(-2deg)` }} />
      </div>
      <AccentText b={b} text={text} size={size} delay={20} />
    </>
  );
};

const Bars: React.FC<{ b: Brand; page: Page; sc: Extract<Scene, { type: "bars" }> }> = ({ b, page, sc }) => {
  const max = Math.max(sc.before.value, sc.after.value, 1);
  const row = (label: string, value: number, tone: string, d: number) => {
    const p = useP(d, "smooth", b);
    return (
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 40, fontWeight: 700 }}>
          <span>{localNum(page, label)}</span>
          <span style={{ color: tone, fontVariantNumeric: "tabular-nums" }}>{localNum(page, Math.round(value * p).toLocaleString("en-US") + (sc.unit ?? ""))}</span>
        </div>
        <div style={{ height: 54, borderRadius: 16, background: "rgba(255,255,255,0.06)", overflow: "hidden" }}>
          <div style={{ height: "100%", width: `${(value / max) * 100 * p}%`, borderRadius: 16, background: tone }} />
        </div>
      </div>
    );
  };
  return (
    <Safe center>
      <AccentText b={b} text={sc.title} size={page === "BN" ? 76 : 82} delay={0} />
      {row(sc.before.label, sc.before.value, b.colors.alert, 10)}
      {row(sc.after.label, sc.after.value, b.colors.hero, 26)}
    </Safe>
  );
};

const Typing: React.FC<{ b: Brand; page: Page; sc: Extract<Scene, { type: "type" }> }> = ({ b, page, sc }) => {
  const f = useCurrentFrame();
  const chars = Math.floor(Math.max(0, f - 12) * 1.6); // ~48 chars per second
  const shown = sc.prompt.slice(0, chars);
  const caret = Math.floor(f / 15) % 2 === 0;
  return (
    <Safe center>
      <AccentText b={b} text={sc.title} size={page === "BN" ? 72 : 78} delay={0} />
      <Entrance b={b} delay={6}>
        <div style={{ borderRadius: 30, overflow: "hidden", border: `2px solid ${b.colors.line}`, background: "#0A1526", boxShadow: "0 40px 80px -24px rgba(0,0,0,0.6)" }}>
          <div style={{ display: "flex", gap: 12, padding: "20px 26px", borderBottom: `2px solid ${b.colors.line}` }}>
            {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <span key={c} style={{ width: 18, height: 18, borderRadius: 9, background: c }} />)}
          </div>
          <div style={{ minHeight: 420, padding: "32px 36px", fontFamily: b.fonts.mono, fontSize: 36, lineHeight: 1.5, color: "#DCE6F2", whiteSpace: "pre-wrap" }}>
            {shown}<span style={{ opacity: caret ? 1 : 0, color: b.colors.hero }}>▍</span>
          </div>
        </div>
      </Entrance>
    </Safe>
  );
};

const Tick: React.FC<{ b: Brand; delay: number }> = ({ b, delay }) => {
  const p = useP(delay, "snappy", b);
  return (
    <svg width="64" height="64" viewBox="0 0 64 64" style={{ flex: "0 0 auto" }}>
      <rect x="3" y="3" width="58" height="58" rx="16" fill={p > 0.5 ? b.colors.hero : "none"} stroke={b.colors.hero} strokeWidth="4" />
      <path d="M17 33 L28 44 L47 22" fill="none" stroke={b.colors.onHero} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="48" strokeDashoffset={48 * (1 - p)} />
    </svg>
  );
};

const SceneView: React.FC<{ sc: Scene; page: Page; b: Brand }> = ({ sc, page, b }) => {
  const big = page === "BN" ? 92 : 100;
  switch (sc.type) {
    case "hook":
      // Hook is readable at frame 0 (search keyword on screen in the first 2 s).
      if (sc.style === "punch") return <Safe center><PunchWords b={b} words={sc.text.split(/\s+/)} size={big + 40} instant /></Safe>;
      if (sc.style === "strike" && sc.wrong) return <Safe center><Strike b={b} page={page} wrong={sc.wrong} text={sc.text} size={big + 10} /></Safe>;
      return <Safe center><Breathe><AccentText b={b} text={sc.text} size={big + 20} delay={-24} /></Breathe></Safe>;
    case "stat":
      return (
        <Safe center>
          <Breathe><Counter b={b} page={page} value={sc.value} prefix={sc.prefix} suffix={sc.suffix} decimals={sc.decimals} size={300} delay={4} /></Breathe>
          <Entrance b={b} delay={14}><div style={{ fontSize: 52, fontWeight: 700, lineHeight: 1.3 }}>{localNum(page, sc.label)}</div></Entrance>
        </Safe>
      );
    case "steps":
    case "checklist":
      return (
        <Safe center>
          <AccentText b={b} text={sc.title} size={big - 10} delay={2} />
          <div style={{ display: "flex", flexDirection: "column", gap: 26, marginTop: 10 }}>
            {sc.items.slice(0, 4).map((t, i) => (
              <Entrance key={i} b={b} delay={12 + i * 14}>
                <Card b={b} style={{ display: "flex", alignItems: "center", gap: 30, padding: "28px 32px" }}>
                  {sc.type === "checklist" ? <Tick b={b} delay={20 + i * 14} /> : (
                    <div style={{ flex: "0 0 auto", width: 84, height: 84, borderRadius: 22, display: "flex", alignItems: "center", justifyContent: "center", border: `4px solid ${b.colors.hero}`, color: b.colors.hero, fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: 42 }}>{localNum(page, i + 1)}</div>
                  )}
                  <div style={{ fontSize: 46, lineHeight: 1.28, fontWeight: 700 }}>{localNum(page, t)}</div>
                </Card>
              </Entrance>
            ))}
          </div>
        </Safe>
      );
    case "compare":
      return (
        <Safe center>
          <Entrance b={b} delay={4}><Card b={b} tone={b.colors.alert}><Label b={b} page={page} tone={b.colors.alert}>{sc.before.label}</Label><div style={{ marginTop: 18, fontSize: 52, lineHeight: 1.28, fontWeight: 700 }}>{localNum(page, sc.before.text)}</div></Card></Entrance>
          <Entrance b={b} delay={22}><Card b={b} tone={b.colors.good}><Label b={b} page={page} tone={b.colors.good}>{sc.after.label}</Label><div style={{ marginTop: 18, fontSize: 52, lineHeight: 1.28, fontWeight: 700 }}>{localNum(page, sc.after.text)}</div></Card></Entrance>
        </Safe>
      );
    case "versus": {
      // "How most people do it" vs "how we do it": stacked cards (readable on a phone), VS badge pops on the seam.
      const vs = useP(16, "bouncy", b);
      const card = (side: { label: string; points: string[] }, tone: string, d: number) => (
        <Entrance b={b} delay={d}>
          <Card b={b} tone={tone} style={{ padding: "34px 40px" }}>
            <Label b={b} page={page} tone={tone}>{side.label}</Label>
            {side.points.slice(0, 3).map((t, i) => <div key={i} style={{ marginTop: 16, fontSize: 46, lineHeight: 1.28, fontWeight: 700 }}>{localNum(page, t)}</div>)}
          </Card>
        </Entrance>
      );
      return (
        <Safe center>
          <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 56 }}>
            {card(sc.them, b.colors.alert, 2)}
            {card(sc.us, b.colors.good, 20)}
            <div style={{ position: "absolute", left: "50%", top: "50%", width: 104, height: 104, marginLeft: -52, marginTop: -52, borderRadius: 52, background: b.colors.hero, color: b.colors.onHero, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: 38, transform: `scale(${vs})`, boxShadow: `0 0 50px ${b.colors.hero}66` }}>VS</div>
          </div>
        </Safe>
      );
    }
    case "bars":
      return <Bars b={b} page={page} sc={sc} />;
    case "type":
      return <Typing b={b} page={page} sc={sc} />;
    case "punch":
      return <Safe center><PunchWords b={b} words={sc.words} size={big + 50} /></Safe>;
    case "statement":
      return <Safe center><Breathe><AccentText b={b} text={sc.text} size={big} delay={3} /></Breathe></Safe>;
    case "end":
      return (
        <Safe center>
          {sc.owner_photo && <div style={{ display: "flex", justifyContent: "center" }}><OwnerCutout src={sc.owner_photo} height={620} /></div>}
          <AccentText b={b} text={sc.cue} size={big - 16} delay={4} />
          <Entrance b={b} delay={16}><div style={{ fontSize: 38, fontWeight: 800, color: b.colors.hero }}>{b.handle}</div></Entrance>
        </Safe>
      );
  }
};

// Slow progress bar: shows how long is left (retention cue).
const Progress: React.FC<{ b: Brand }> = ({ b }) => {
  const f = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  return <div style={{ position: "absolute", left: 80, right: 80, top: 200, height: 8, borderRadius: 4, background: b.colors.line }}>
    <div style={{ height: 8, borderRadius: 4, background: b.colors.hero, width: `${interpolate(f, [0, durationInFrames - 1], [0, 100], { extrapolateLeft: "clamp", extrapolateRight: "clamp" })}%` }} />
  </div>;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const presentations: TransitionPresentation<any>[] = [slide({ direction: "from-bottom" }), wipe({ direction: "from-left" }), slide({ direction: "from-right" }), fade()];

// Sound map: whoosh on every cut, pop per list item, riser into a payoff, bass hit when it lands.
const Sfx: React.FC<{ scenes: Scene[]; starts: number[] }> = ({ scenes, starts }) => (
  <>
    {starts.map((s, i) => (
      <Sequence key={`w${i}`} from={Math.max(0, s - 3)} durationInFrames={20}><Audio src={staticFile(i === 0 ? "sfx/hit.wav" : "sfx/whoosh.wav")} volume={0.5} /></Sequence>
    ))}
    {scenes.flatMap((sc, i) => {
      const s = starts[i];
      if (sc.type === "steps" || sc.type === "checklist") return sc.items.slice(0, 4).map((_, k) => <Sequence key={`p${i}${k}`} from={s + 10 + k * 14} durationInFrames={10}><Audio src={staticFile("sfx/pop.wav")} volume={0.45} /></Sequence>);
      if (sc.type === "punch") return sc.words.map((_, k) => <Sequence key={`p${i}${k}`} from={s + k * 8} durationInFrames={10}><Audio src={staticFile("sfx/pop.wav")} volume={0.5} /></Sequence>);
      if (sc.type === "stat" || sc.type === "bars") return [
        <Sequence key={`r${i}`} from={Math.max(0, s - 24)} durationInFrames={26}><Audio src={staticFile("sfx/riser.wav")} volume={0.35} /></Sequence>,
        <Sequence key={`k${i}`} from={s + 4} durationInFrames={36}><Audio src={staticFile("sfx/tick.wav")} volume={0.3} /></Sequence>,
        <Sequence key={`h${i}`} from={s + 30} durationInFrames={20}><Audio src={staticFile("sfx/hit.wav")} volume={0.45} /></Sequence>,
      ];
      if (sc.type === "versus") return [<Sequence key={`v${i}`} from={s + 14} durationInFrames={20}><Audio src={staticFile("sfx/hit.wav")} volume={0.45} /></Sequence>];
      return [];
    })}
  </>
);

export const SceneReel: React.FC<ReelProps> = (p) => {
  const b = brandOf(p.page);
  const starts: number[] = [];
  p.scenes.reduce((s, sc) => { starts.push(s); return s + len(sc.sec) - T; }, 0);
  return (
    <Frame b={b}>
      <AbsoluteFill>
        <TransitionSeries>
          {p.scenes.flatMap((sc, i) => {
            const seq = (
              <TransitionSeries.Sequence key={`s${i}`} durationInFrames={len(sc.sec)}>
                <AbsoluteFill>{sc.bg && <BRoll src={sc.bg} />}<Ghost n={i + 1} b={b} /><SceneView sc={sc} page={p.page} b={b} /></AbsoluteFill>
              </TransitionSeries.Sequence>
            );
            return i === 0 ? [seq] : [
              <TransitionSeries.Transition key={`t${i}`} presentation={presentations[(i - 1) % presentations.length]} timing={springTiming({ config: b.spring.smooth, durationInFrames: T })} />,
              seq,
            ];
          })}
        </TransitionSeries>
        <Progress b={b} />
      </AbsoluteFill>
      {p.music !== false && <Audio src={staticFile("sfx/bed.wav")} volume={0.22} />}
      <Sfx scenes={p.scenes} starts={starts} />
    </Frame>
  );
};

export const REELS: Record<string, React.FC<ReelProps>> = { V1: SceneReel, V2: SceneReel, V3: SceneReel, V4: SceneReel, V5: SceneReel, V6: SceneReel, V7: SceneReel };
