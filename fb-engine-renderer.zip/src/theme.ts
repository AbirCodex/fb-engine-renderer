// Single source of truth for both brands. Never inline colors or easings in components.
import { Easing } from "remotion";

export type Page = "EN" | "BN";

const base = {
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  safe: 80, // px margin on every side (spec section 15)
} as const;

export const brands = {
  EN: {
    ...base,
    handle: "Abir AdCode Lab",
    byline: "ABIR HASSAN",
    colors: {
      bg: "#0B1F3A",
      surface: "#12294A",
      line: "rgba(245,247,250,0.10)",
      hero: "#C6F432", // max one hero element per frame
      alert: "#FF5A4E",
      good: "#C6F432",
      text: "#F5F7FA",
      dim: "#9FB0C8",
      onHero: "#0B1F3A",
    },
    fonts: { display: "'Archivo Black', 'Inter', sans-serif", body: "'Inter', sans-serif", mono: "'JetBrains Mono', 'Courier New', monospace" },
    displayWeight: 400, // Archivo Black ships one heavy weight
    tracking: "-0.02em",
  },
  BN: {
    ...base,
    handle: "Abir Hassan · Ads, AI & Business Growth",
    byline: "আবির হাসান",
    colors: {
      bg: "#0A3533",
      surface: "#0E4D4A",
      line: "rgba(247,243,234,0.12)",
      hero: "#F5A623",
      alert: "#FF6B5B",
      good: "#7DDCB0",
      text: "#F7F3EA",
      dim: "#A9C7C2",
      onHero: "#0A3533",
    },
    fonts: { display: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif", body: "'Hind Siliguri', 'Noto Sans Bengali', sans-serif", mono: "'JetBrains Mono', 'Courier New', monospace" },
    displayWeight: 700,
    tracking: "0em", // negative tracking breaks Bangla conjuncts
  },
} as const;

export type Brand = (typeof brands)[Page];
export const brandOf = (page: Page): Brand => brands[page] ?? brands.EN;

// Bangla digits for BN prose numbers (spec: Bengali digits only).
const BN_DIGITS = "০১২৩৪৫৬৭৮৯";
export const localNum = (page: Page, s: string | number) =>
  page === "BN" ? String(s).replace(/[0-9]/g, (d) => BN_DIGITS[Number(d)]) : String(s);
