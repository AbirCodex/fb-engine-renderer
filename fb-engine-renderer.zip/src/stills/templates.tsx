import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile } from "remotion";
import { AccentText, Counter, Entrance, Footer, Frame, OwnerCutout, useP } from "../components/kit";
import { brandOf, localNum, Page } from "../theme";

// Brief produced by A4 Art Director (spec section 15). Every field is optional except page + headline.
export type CardProps = {
  page: Page;
  template: string;
  eyebrow?: string;
  headline: string; // max 7 words, accent in [brackets]
  anchor?: { value: number; prefix?: string; suffix?: string; decimals?: number; label?: string };
  items?: string[]; // steps, mistakes, checklist
  before?: { label: string; points: string[] };
  after?: { label: string; points: string[] };
  prompt?: string;
  quote?: string;
  owner_photo?: string; // real photo cutout (png with transparency) - never AI generated
  image?: string; // real photo for the poster (Pexels or owner) - https URL or public/ path
  micro_cue?: string;
  source?: string;
};

// Stills are rendered at the last frame, so every entrance has finished.
export const STILL_FRAMES = 45;

const Middle: React.FC<{ children: React.ReactNode; gap?: number }> = ({ children, gap = 0 }) => (
  <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", gap, paddingBottom: 40 }}>{children}</div>
);

const Box: React.FC<{ border: string; bg: string; children: React.ReactNode; style?: React.CSSProperties }> = ({ border, bg, children, style }) => (
  <div style={{ borderRadius: 28, border: `2px solid ${border}`, background: bg, padding: 36, ...style }}>{children}</div>
);

// T01 Stat hero: one giant number (0.5s anchor) -> headline (1.2s) -> cue (2s)
export const StatHero: React.FC<CardProps> = (p) => {
  const b = brandOf(p.page);
  const a = p.anchor ?? { value: 0 };
  return (
    <Frame b={b}>
      <Middle gap={64}>
      <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
        <Counter b={b} page={p.page} value={a.value} prefix={a.prefix} suffix={a.suffix} decimals={a.decimals} size={260} delay={3} />
        {a.label && <Entrance b={b} delay={8}><div style={{ fontSize: 38, fontWeight: 600, color: b.colors.dim, maxWidth: 920 }}>{a.label}</div></Entrance>}
      </div>
      <AccentText b={b} text={p.headline} size={p.page === "BN" ? 76 : 80} delay={10} />
      </Middle>
      <Footer b={b} page={p.page} cue={p.micro_cue} delay={18} />
    </Frame>
  );
};

// T02 Prompt card: code-editor window; full prompt lives in the first comment.
export const PromptCard: React.FC<CardProps> = (p) => {
  const b = brandOf(p.page);
  const lines = (p.prompt ?? "").split("\n").slice(0, 9);
  return (
    <Frame b={b}>
      <Middle gap={52}>
      <AccentText b={b} text={p.headline} size={p.page === "BN" ? 68 : 72} delay={2} />
      <Entrance b={b} delay={10}>
        <div style={{ borderRadius: 26, overflow: "hidden", border: `2px solid ${b.colors.line}`, background: "#0A1526", boxShadow: "0 40px 80px -24px rgba(0,0,0,0.6)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "18px 24px", borderBottom: `2px solid ${b.colors.line}` }}>
            {["#FF5F57", "#FEBC2E", "#28C840"].map((c) => <span key={c} style={{ width: 16, height: 16, borderRadius: 8, background: c }} />)}
            <span style={{ marginLeft: 14, fontSize: 22, color: b.colors.dim, fontFamily: b.fonts.mono }}>prompt.txt</span>
          </div>
          <div style={{ position: "relative", padding: "28px 32px 40px", fontFamily: b.fonts.mono, fontSize: 27, lineHeight: 1.55, color: "#DCE6F2", whiteSpace: "pre-wrap" }}>
            {lines.map((l, i) => <div key={i}><span style={{ color: "#4B5D77", marginRight: 22 }}>{String(i + 1).padStart(2, "0")}</span>{l}</div>)}
            <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, height: 140, background: "linear-gradient(transparent, #0A1526)" }} />
          </div>
        </div>
      </Entrance>
      </Middle>
      <Footer b={b} page={p.page} cue={p.micro_cue} delay={18} />
    </Frame>
  );
};

// T03 Before / After: two stacked cards, red then green.
export const BeforeAfter: React.FC<CardProps> = (p) => {
  const b = brandOf(p.page);
  const col = (side: "before" | "after", d: number) => {
    const data = p[side] ?? { label: side, points: [] };
    const tone = side === "before" ? b.colors.alert : b.colors.good;
    return (
      <Entrance b={b} delay={d}>
        <Box border={`${tone}66`} bg={`${tone}12`}>
          <div style={{ fontSize: 30, fontWeight: 800, letterSpacing: p.page === "BN" ? "0.02em" : "0.12em", textTransform: "uppercase", color: tone, marginBottom: 18 }}>{data.label}</div>
          {data.points.slice(0, 3).map((t, i) => (
            <div key={i} style={{ display: "flex", gap: 18, fontSize: 34, lineHeight: 1.35, marginTop: i ? 14 : 0 }}>
              <span style={{ flex: "0 0 auto", marginTop: 14, width: 14, height: 14, borderRadius: 7, background: tone }} />
              <span>{localNum(p.page, t)}</span>
            </div>
          ))}
        </Box>
      </Entrance>
    );
  };
  return (
    <Frame b={b}>
      <Middle gap={46}>
      <AccentText b={b} text={p.headline} size={p.page === "BN" ? 66 : 70} delay={2} />
      <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
        {col("before", 10)}
        {col("after", 16)}
      </div>
      </Middle>
      <Footer b={b} page={p.page} cue={p.micro_cue} delay={22} />
    </Frame>
  );
};

// T05 Step flow / T14 Mistake list share one numbered-list layout.
const NumberedList: React.FC<CardProps & { mode: "steps" | "mistakes" }> = (p) => {
  const b = brandOf(p.page);
  const items = (p.items ?? []).slice(0, 5);
  const tone = p.mode === "mistakes" ? b.colors.alert : b.colors.hero;
  return (
    <Frame b={b}>
      <Middle gap={50}>
      <AccentText b={b} text={p.headline} size={p.page === "BN" ? 66 : 70} delay={2} />
      <div style={{ display: "flex", flexDirection: "column", gap: 22 }}>
        {items.map((t, i) => (
          <Entrance key={i} b={b} delay={9 + i * 4}>
            <div style={{ display: "flex", alignItems: "center", gap: 28, padding: "22px 28px", borderRadius: 22, background: "rgba(255,255,255,0.045)", border: `2px solid ${b.colors.line}` }}>
              <div style={{ flex: "0 0 auto", width: 64, height: 64, borderRadius: 18, display: "flex", alignItems: "center", justifyContent: "center", background: p.mode === "steps" && i === 0 ? tone : "transparent", border: `3px solid ${tone}`, color: p.mode === "steps" && i === 0 ? b.colors.onHero : tone, fontFamily: b.fonts.display, fontWeight: b.displayWeight, fontSize: 32 }}>
                {p.mode === "mistakes" ? "✕" : localNum(p.page, i + 1)}
              </div>
              <div style={{ fontSize: items.length > 4 ? 32 : 36, lineHeight: 1.3, fontWeight: 600 }}>{localNum(p.page, t)}</div>
            </div>
          </Entrance>
        ))}
      </div>
      </Middle>
      <Footer b={b} page={p.page} cue={p.micro_cue} delay={9 + items.length * 4 + 4} />
    </Frame>
  );
};
export const StepFlow: React.FC<CardProps> = (p) => <NumberedList {...p} mode="steps" />;
export const MistakeList: React.FC<CardProps> = (p) => <NumberedList {...p} mode="mistakes" />;

// T11 Quote + owner photo (falls back to a monogram until real photos arrive).
export const QuoteOwner: React.FC<CardProps> = (p) => {
  const b = brandOf(p.page);
  const q = useP(4, "smooth", b);
  return (
    <Frame b={b}>
      <div style={{ marginTop: 40, fontFamily: b.fonts.display, fontSize: 200, lineHeight: 0.8, color: b.colors.hero, opacity: q, transform: `scale(${interpolate(q, [0, 1], [0.7, 1])})`, transformOrigin: "0 50%" }}>“</div>
      <div style={{ maxWidth: p.owner_photo ? 640 : 920 }}><AccentText b={b} text={p.quote ?? p.headline} size={p.page === "BN" ? 62 : 64} delay={8} /></div>
      <div style={{ position: "absolute", right: 0, bottom: 150 }}>
        {p.owner_photo ? <OwnerCutout src={p.owner_photo} height={720} still /> : null}
      </div>
      <Footer b={b} page={p.page} cue={p.micro_cue} delay={18} />
    </Frame>
  );
};

// T20 Poster: the format the top BN/US creators use most (big centered 2-3 line headline,
// 1-2 coloured words, small byline on top, a real photo filling the lower half). Details live in the comments.
export const Poster: React.FC<CardProps> = (p) => {
  const b = brandOf(p.page);
  const by = useP(0, "smooth", b);
  return (
    <AbsoluteFill style={{ background: "#06080B", fontFamily: b.fonts.body, color: b.colors.text }}>
      {p.image && (
        <AbsoluteFill style={{ top: "42%" }}>
          <Img src={p.image.startsWith("http") ? p.image : staticFile(p.image)} style={{ width: "100%", height: "100%", objectFit: "cover", filter: "saturate(1.05) contrast(1.05)" }} />
          <AbsoluteFill style={{ background: "linear-gradient(180deg, #06080B 0%, rgba(6,8,11,0.55) 30%, rgba(6,8,11,0) 60%, rgba(6,8,11,0.35) 100%)" }} />
        </AbsoluteFill>
      )}
      <AbsoluteFill style={{ padding: "70px 70px 0", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: p.image ? "flex-start" : "center", textAlign: "center" }}>
        <div style={{ opacity: by, fontSize: 30, fontWeight: 700, letterSpacing: p.page === "BN" ? "0.02em" : "0.18em", color: b.colors.dim, marginBottom: 34 }}>{b.byline}</div>
        <div style={{ display: "flex", justifyContent: "center" }}>
          <AccentText b={b} text={p.headline} size={p.page === "BN" ? 92 : 96} delay={2} heroWords />
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

export const TEMPLATES: Record<string, React.FC<CardProps>> = {
  T01: StatHero,
  T02: PromptCard,
  T03: BeforeAfter,
  T05: StepFlow,
  T11: QuoteOwner,
  T14: MistakeList,
  T20: Poster,
};
