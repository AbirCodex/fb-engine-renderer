// Deterministic SFX kit (no downloads, no licensing risk): bed, whoosh, hit, tick as 16-bit 44.1k WAV.
const fs = require("fs");
const SR = 44100;
const wav = (name, samples) => {
  const n = samples.length, buf = Buffer.alloc(44 + n * 2);
  buf.write("RIFF", 0); buf.writeUInt32LE(36 + n * 2, 4); buf.write("WAVEfmt ", 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(SR, 24); buf.writeUInt32LE(SR * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write("data", 36); buf.writeUInt32LE(n * 2, 40);
  for (let i = 0; i < n; i++) buf.writeInt16LE(Math.max(-1, Math.min(1, samples[i])) * 32000 | 0, 44 + i * 2);
  fs.writeFileSync(`public/sfx/${name}.wav`, buf);
};
let seed = 7; const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647) * 2 - 1;
const arr = (sec, f) => Array.from({ length: Math.round(sec * SR) }, (_, i) => f(i / SR, i));

// whoosh: band-limited noise with rising-then-falling envelope
let lp = 0;
wav("whoosh", arr(0.45, (t) => { lp += 0.08 * (rnd() - lp); const e = Math.sin(Math.PI * Math.min(1, t / 0.45)) ** 2; return lp * e * 2.2; }));
// hit: sine kick with pitch drop + click
wav("hit", arr(0.5, (t) => { const f = 110 * Math.exp(-t * 9) + 45; return Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 7) * 0.9 + (t < 0.004 ? rnd() * 0.4 : 0); }));
// tick: short high blips every 60 ms (counter)
wav("tick", arr(1.2, (t) => { const ph = t % 0.06; return ph < 0.012 ? Math.sin(2 * Math.PI * 2400 * ph) * Math.exp(-ph * 300) * 0.5 * (1 - t / 1.3) : 0; }));
// pop: short pitched blip for list items
wav("pop", arr(0.12, (t) => Math.sin(2 * Math.PI * (900 - t * 3000) * t) * Math.exp(-t * 40) * 0.6));
// riser: noise + rising tone into a payoff
let lp2 = 0;
wav("riser", arr(0.85, (t) => { lp2 += (0.02 + t * 0.2) * (rnd() - lp2); const e = (t / 0.85) ** 2; return (lp2 * 1.5 + Math.sin(2 * Math.PI * (200 + 900 * t) * t) * 0.15) * e; }));
// bed: 32 s detuned pad (Am - F - C - G) + soft kick on 100 BPM quarter notes
const chords = [[220, 261.63, 329.63], [174.61, 220, 261.63], [261.63, 329.63, 392], [196, 246.94, 293.66]];
const beat = 60 / 100;
wav("bed", arr(32, (t) => {
  const c = chords[Math.floor(t / (beat * 8)) % 4];
  let pad = 0; c.forEach((f) => { pad += Math.sin(2 * Math.PI * f * t) + Math.sin(2 * Math.PI * f * 1.004 * t); });
  const fade = Math.min(1, t / 1.5, (32 - t) / 2);
  const kt = t % beat; const kick = Math.sin(2 * Math.PI * (60 * Math.exp(-kt * 12) + 40) * kt) * Math.exp(-kt * 9);
  return (pad * 0.045 + kick * 0.35) * fade;
}));
console.log(fs.readdirSync("public/sfx"));
