// FB Engine render service: n8n -> POST JSON brief -> PNG card or MP4 reel.
// Runs on Google Cloud Run or any Docker host (e.g. the Hostinger VPS).
const express = require("express");
const path = require("path");
const os = require("os");
const fs = require("fs");
const crypto = require("crypto");
const { bundle } = require("@remotion/bundler");
const { renderStill, renderMedia, selectComposition } = require("@remotion/renderer");

const PORT = process.env.PORT || 8080;
const SECRET = process.env.RENDER_SECRET || "";
const BROWSER = process.env.BROWSER_EXECUTABLE || undefined; // let Remotion use its own headless shell when unset
const CARD_TEMPLATES = ["T01", "T02", "T03", "T05", "T11", "T14", "T20"];
const SCENE_TYPES = ["hook", "stat", "steps", "checklist", "compare", "versus", "bars", "type", "punch", "statement", "end"];
const STILL_LAST_FRAME = 44; // STILL_FRAMES - 1 in src/stills/templates.tsx

if (!SECRET) console.warn("RENDER_SECRET is not set: every request will be rejected.");

// Trust boundary: the brief comes from an LLM, so check shape and size before rendering.
const words = (s) => String(s || "").replace(/[\[\]]/g, "").trim().split(/\s+/).filter(Boolean).length;
function checkCard(p) {
  const e = [];
  if (!["EN", "BN"].includes(p.page)) e.push("page must be EN or BN");
  if (!CARD_TEMPLATES.includes(p.template)) e.push(`template must be one of ${CARD_TEMPLATES}`);
  if (!p.headline || words(p.headline) > 9) e.push("headline required, max 9 words");
  if (p.items && (!Array.isArray(p.items) || p.items.length > 5)) e.push("items: max 5");
  if (p.prompt && String(p.prompt).length > 900) e.push("prompt too long for the card (full prompt goes in the comment)");
  if (p.template === "T01" && typeof p.anchor?.value !== "number") e.push("T01 needs anchor.value (number)");
  for (const k of ["owner_photo", "image"]) if (p[k] && !/^https:\/\//.test(p[k]) && !/^(owner|photos)\//.test(p[k])) e.push(`${k} must be an https URL or an owner/ or photos/ asset`);
  return e;
}
function checkReel(p) {
  const e = [];
  if (!["EN", "BN"].includes(p.page)) e.push("page must be EN or BN");
  if (!Array.isArray(p.scenes) || p.scenes.length < 2 || p.scenes.length > 8) e.push("scenes: 2-8 required");
  const total = (p.scenes || []).reduce((s, sc) => s + Number(sc.sec || 0), 0);
  if (total < 10 || total > 35) e.push(`total length ${total}s must be 10-35s`);
  (p.scenes || []).forEach((sc, i) => {
    if (!SCENE_TYPES.includes(sc.type)) e.push(`scene ${i}: unknown type ${sc.type}`);
    if (sc.bg && !/^https:\/\/(videos\.pexels\.com|player\.vimeo\.com|[a-z0-9.-]+\.googleusercontent\.com)\//.test(sc.bg)) e.push(`scene ${i}: bg must be a Pexels/Drive https video URL`);
  });
  if (p.scenes?.[0]?.type !== "hook") e.push("first scene must be a hook (keyword on screen at 0-2 s)");
  return e;
}

let serveUrl;
const ready = bundle({ entryPoint: path.join(__dirname, "src/index.ts") }).then((u) => (serveUrl = u));

const app = express();
app.use(express.json({ limit: "1mb" }));
app.get("/health", (_q, r) => r.json({ ok: true, bundled: Boolean(serveUrl) }));

app.use((req, res, next) => {
  const got = Buffer.from(String(req.get("X-Render-Secret") || ""));
  const want = Buffer.from(SECRET);
  if (!SECRET || got.length !== want.length || !crypto.timingSafeEqual(got, want)) return res.status(401).json({ error: "bad secret" });
  next();
});

const tmp = (ext) => path.join(os.tmpdir(), `${crypto.randomUUID()}.${ext}`);
const slug = (s) => String(s || "post").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) || "post";

app.post("/render/card", async (req, res) => {
  const props = req.body?.props || {};
  const errors = checkCard(props);
  if (errors.length) return res.status(422).json({ errors });
  const out = tmp("png");
  try {
    await ready;
    const composition = await selectComposition({ serveUrl, id: "Card", inputProps: props, browserExecutable: BROWSER });
    await renderStill({ serveUrl, composition, inputProps: props, output: out, frame: STILL_LAST_FRAME, imageFormat: "png", browserExecutable: BROWSER });
    res.set("Content-Disposition", `attachment; filename="${slug(req.body.file_slug)}.png"`);
    res.type("png").send(fs.readFileSync(out));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err.message || err) });
  } finally {
    fs.rm(out, { force: true }, () => {});
  }
});

app.post("/render/reel", async (req, res) => {
  const props = req.body?.props || {};
  const errors = checkReel(props);
  if (errors.length) return res.status(422).json({ errors });
  const out = tmp("mp4");
  try {
    await ready;
    const composition = await selectComposition({ serveUrl, id: "Reel", inputProps: props, browserExecutable: BROWSER });
    await renderMedia({ serveUrl, composition, inputProps: props, codec: "h264", crf: 18, outputLocation: out, concurrency: Number(process.env.CONCURRENCY || 2), browserExecutable: BROWSER });
    res.set("Content-Disposition", `attachment; filename="${slug(req.body.file_slug)}.mp4"`);
    res.type("mp4").send(fs.readFileSync(out));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: String(err.message || err) });
  } finally {
    fs.rm(out, { force: true }, () => {});
  }
});

if (require.main === module) app.listen(PORT, () => console.log(`render service on :${PORT}`));
module.exports = { checkCard, checkReel };
