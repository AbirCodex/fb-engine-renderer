// Self-check: validator rules, then one real card render through the HTTP API.
const assert = require("assert");
const fs = require("fs");
process.env.RENDER_SECRET = "local-test-only";
process.env.BROWSER_EXECUTABLE = process.env.BROWSER_EXECUTABLE || "/usr/bin/google-chrome";
const { checkCard, checkReel } = require("./server");

assert.deepStrictEqual(checkCard({ page: "EN", template: "T05", headline: "Fix it in [3 steps]", items: ["a"] }), []);
assert.ok(checkCard({ page: "XX", template: "T99", headline: "" }).length >= 3);
assert.ok(checkCard({ page: "EN", template: "T01", headline: "x" }).some((e) => e.includes("anchor")));
assert.deepStrictEqual(checkReel(require("./samples/props/en_v1.json")), []);
assert.ok(checkReel({ page: "EN", scenes: [{ type: "stat", sec: 3 }, { type: "end", sec: 3 }] }).length >= 2);
console.log("validators ok");

(async () => {
  const { spawn } = require("child_process");
  const srv = spawn("node", ["server.js"], { env: { ...process.env, PORT: "8089" }, stdio: "inherit" });
  const base = "http://localhost:8089";
  for (let i = 0; i < 60; i++) {
    try { const h = await (await fetch(base + "/health")).json(); if (h.bundled) break; } catch {}
    await new Promise((r) => setTimeout(r, 1000));
  }
  const post = (body, key) => fetch(base + "/render/card", { method: "POST", headers: { "content-type": "application/json", ...(key ? { "X-Render-Secret": key } : {}) }, body: JSON.stringify(body) });
  assert.strictEqual((await post({})).status, 401);
  assert.strictEqual((await post({ props: { page: "EN", template: "T01", headline: "x" } }, "local-test-only")).status, 422);
  const t0 = Date.now();
  const ok = await post({ file_slug: "Prompt drop: review hooks", props: require("./samples/props/en_t02.json") }, "local-test-only");
  assert.strictEqual(ok.status, 200);
  assert.match(ok.headers.get("content-disposition"), /prompt-drop-review-hooks\.png/);
  const buf = Buffer.from(await ok.arrayBuffer());
  fs.writeFileSync("out/api_card.png", buf);
  console.log(`api ok: 401/422/200, card ${buf.length} bytes in ${Date.now() - t0} ms`);
  srv.kill();
})().catch((e) => { console.error(e); process.exit(1); });
