#!/usr/bin/env bash
# One-shot install of the FB Engine render service on a Docker VPS (tested target: Hostinger 2 GB).
# Usage (from this folder):  sudo bash deploy.sh
# Re-run any time to update: it rebuilds the image and restarts the container, keeping the same secret.
set -euo pipefail
cd "$(dirname "$0")"

# 1) 4 GB swap so a Chrome render never pushes n8n out of RAM (skipped if swap already exists).
if [ "$(swapon --show | wc -l)" -eq 0 ]; then
  fallocate -l 4G /swapfile && chmod 600 /swapfile && mkswap /swapfile >/dev/null && swapon /swapfile
  grep -q '^/swapfile' /etc/fstab || echo '/swapfile none swap sw 0 0' >> /etc/fstab
  echo "swap: 4G added"
fi

# 2) Shared secret between n8n and the renderer (generated once, kept on the server only).
[ -f .render_secret ] || (openssl rand -hex 24 > .render_secret && chmod 600 .render_secret)
SECRET="$(cat .render_secret)"

# 3) Build.
docker build -t fbrender:latest .

# 4) Join n8n's Docker network when n8n runs in Docker, so n8n reaches us as http://fbrender:8080.
N8N="$(docker ps --format '{{.Names}} {{.Image}}' | awk 'tolower($0) ~ /n8n/ {print $1; exit}')"
NET=""
[ -n "$N8N" ] && NET="$(docker inspect -f '{{range $k, $v := .NetworkSettings.Networks}}{{$k}} {{end}}' "$N8N" | awk '{print $1}')"

docker rm -f fbrender >/dev/null 2>&1 || true
if [ -n "$NET" ]; then
  docker run -d --name fbrender --restart unless-stopped --network "$NET" \
    --memory 1400m --memory-swap 3g -e RENDER_SECRET="$SECRET" -e CONCURRENCY=1 fbrender:latest >/dev/null
  URL="http://fbrender:8080"
else
  docker run -d --name fbrender --restart unless-stopped -p 127.0.0.1:8080:8080 \
    --memory 1400m --memory-swap 3g -e RENDER_SECRET="$SECRET" -e CONCURRENCY=1 fbrender:latest >/dev/null
  URL="http://localhost:8080"
fi

# 5) Health check (first start bundles the project, ~30-60 s).
for i in $(seq 1 30); do
  if docker exec fbrender node -e "fetch('http://localhost:8080/health').then(r=>r.json()).then(j=>process.exit(j.bundled?0:1)).catch(()=>process.exit(1))"; then
    OK=1; break; fi
  sleep 5
done
echo
echo "================ FB Engine renderer ================"
[ "${OK:-0}" = 1 ] && echo "status        : READY" || echo "status        : NOT READY — run: docker logs fbrender"
echo "renderer_url  : $URL   (n8n container: ${N8N:-not in docker})"
echo "n8n credential: Header Auth  ->  Name: X-Render-Secret   Value: $SECRET"
echo "===================================================="
